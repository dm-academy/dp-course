from time import sleep


def entry(request):
    sleep(10)
    return "Function completed"